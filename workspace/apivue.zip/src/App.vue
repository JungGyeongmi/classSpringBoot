<template>
  <div id="nav">
    <ul>
      <li>
        <router-link to="/">Home</router-link>
      </li>
      <li>
        <router-link to="/join">회원 가입</router-link>
      </li>
      <li>
        <router-link to="/login">Login</router-link>
      </li>
      <li>
        <router-link to="/list">회원 목록</router-link>
      </li>
      <li>
        <router-link to="/update">회원 수정</router-link>
      </li>
      <li>
        <router-link to="/delete">회원 삭제</router-link>
      </li>
      <li>
        <router-link to="/detail">회원 상세(MyPage)</router-link>
      </li>
    </ul>
  </div>
  <router-view/>
</template>

<style>
ul{list-style: none;}
li{display: inline-block; width: 150px;}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
