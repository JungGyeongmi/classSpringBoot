<template>
  <div>
    <h1>{{ message }}</h1>
  </div>
</template>
<script>
export default {
  name: 'TheHome',
  setup(){
    
  },
  data() {
    return {message: 'Home'}
  }
}
</script>
<style>

</style>