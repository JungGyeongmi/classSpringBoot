<template>
  <div>
    <h1>{{ message }}</h1>
    <form>
      <input type="text" placeholder="Email" ref="username" v-model="state.username" /><br>
      <input type="password" placeholder="Password" ref="password" v-model="state.password" /><br>
      <button type="button" @click="handleLogin">로그인</button>
    </form>
  </div>
</template>
<script>
import { reactive, ref } from '@vue/reactivity';
import axios from 'axios';
import { useRouter } from 'vue-router';
import{ useStore } from 'vuex';

export default {
  name: 'TheLogin',

  // vue2.0 created()와 같았음.
  setup() {
    const router = useRouter();
    const store = useStore();

    const state = reactive({
      username : '',
      password : '',
    });

    const username = ref('');
    const password = ref('');

    const handleLogin = async() => {
      if(state.username === ''){
        username.value.focus(); //ref 는 .value로 접근해야된다
        return false;
      } else if(state.password === '') {
        password.value.focus(); 
        return false;
      }

      const url = 'http:localhost:9090/apiserver/login';
      const headers = {"Content-Type" : "application/json"};
      const body = {
        username : state.username,
        password : state.password,
      }
      const response = await axios.get(url, body, {headers});
      console.log(response.data);

      if(response.data.status === 200){
        console.log(response.data.token);

        sessionStorage.setItem("TOKEN", response.data.token);
        alert('로그인이 되었습니다.');

        // actions를 호출하여 store/state 변수를 변경하려고 함.
        store.dispatch("handlData", {});

        const curl = sessionStorage.getItem("CURL");
        if(curl === null){
          router.push({name: "TheHome"});
          store.commit("setMenu", "/");
        } else { //이동하고자 하는 페이지가 존재하면 string->object.JSON.parse
          const query = JSON.parse(sessionStorage.getItem("CURL_QUERY"));
          const params = JSON.parse(sessionStorage.getItem("CURL_PARAMS"));
          router.push({ name:curl, query:query, params: params})
        }
      }
    };

    return {
      state,
      username,password,
      handleLogin,
    }
  },
}
</script>
<style>

</style>