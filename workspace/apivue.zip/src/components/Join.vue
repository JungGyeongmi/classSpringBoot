<template>
  <div>
    <h1>{{ message }}</h1>
    <form>
      <label>
        <input type="text" ref="email" v-model="state.email" placeholder="Email"
          required autofocus class="form-control"/> 
          <!-- @keyup="emailCheckHandler" -->
        {{state.emailCheck}}
      </label><br>
      <label>비밀번호
        <input type="password" ref="password" v-model="state.password"/>
      </label><br>
      <label>비밀번호 재입력
        <input type="password" ref="repassword" v-model="state.repassword"/>
      </label><br>
      <label>Mobile
        <input type="text" ref="mobile" v-model="state.mobile"/>
      </label><br>
      <label>이름
        <input type="text" ref="name" v-model="state.name"/>
      </label><br>
      <label>
        <input type="button" @click="joinHandler" value="회원가입"/>
      </label>
    </form>
  </div>
</template>
<script>
import { reactive, ref } from 'vue';
import axios from 'axios';
import { useRouter} from 'vue-router';

export default {
  name: 'TheJoin',
  setup() {
    const router = useRouter();

    // vue2.x의 Vue.observable() API와 동일,  
    // JavaScript 객체에서 반응형 상태를 생성하기 위함. 오브젝트 변화 감지
    // 반응형 변환이 deep! 그래서 전달된 객체의 모든 중첩된 속성에 영향을 미친다.
    // Vue 반응형 시스템의 본질이란? 컴포넌트의 data()에서 객체(속성)을 반환할 때
    // 내부적으로 reactive()에 의해 반응형으로 생성되어서 템플릿으로 반영되는데 그때
    // 반응형 속성을 사용하는 렌더 함수로 컴파일 된다.
    const state = reactive({
      email      : '',
      password   : '',
      repassword : '',
      mobile     : '',
      name       : '',
      emailCheck : '',
    });

    // ref Vue 2.x에서는 vm.$refs 사용되었고, Vue 인스턴스가 관리하는 자식 DOM 엘리먼트
    // 또는 다른 컴포넌트를 참조하는데 사용
    const email = ref('');
    const password = ref('');
    const repassword = ref('');
    const mobile = ref('');
    const name = ref('');

    // const emailCheckHandler = async() =>{
    //   console.log(state.email);
    //   const url=`http://localhost:9090/apiserver/member/emailCheck?email=${state.email}`;
    //   const headers = {"Content-Type" : "application/json"};
    //   const response = await axios.get(url, {headers});
    //   console.log(response.data);
    //   if(response.data.status === 200) {
    //     state.emailCheck=(response.data.result === 1)?"사용불가":"사용가능";
    //   } else {
    //     state.emailCheck = "중복 확인";
    //   }
    // }

    const joinHandler = async() => {
      
      if(state.email === ''){
        // alert('email 을 입력하세요');
        // email.value.before('email을 입력하세요 ');
        email.value.focus(); //ref 는 .value로 접근해야된다
        return false;
      } else if(state.password === '') {
        alert('password 를 입력하세요');
        // password.value.append('password 를 입력하세요 ');
        password.value.focus(); //ref 는 .value로 접근해야된다
        return false;
      } else if(state.repassword === '') {
        alert('repassword 를 입력하세요');
        // repassword.value.append('repassword 를 입력하세요 ');
        repassword.value.focus(); //ref 는 .value로 접근해야된다
        return false;
      } else if(state.mobile === '') {
        alert('mobile 를 입력하세요');
        // mobile.value.append('mobile 를 입력하세요 ');
        mobile.value.focus(); //ref 는 .value로 접근해야된다
        return false;
      } else if(state.name === '') {
        alert('name 를 입력하세요');
        // name.value.append('name 를 입력하세요 ');
        name.value.focus(); //ref 는 .value로 접근해야된다
        return false;
      } else if(state.password != state.repassword) {
        alert('password와 repassword를 확인하세요');
        // password.value.append('name 를 입력하세요 ');
        password.value = ''; repassword.value = '';
        password.value.focus(); //ref 는 .value로 접근해야된다
        return false;      
      }
      const url=`http://localhost:9090/apiserver/member/register`;
      const headers = {"Content-Type" : "application/json"};
      const body = {
        email : state.email,
        password : state.password,
        mobile : state.mobile,
        name : state.name,
      }
      const response = await axios.get(url, body, {headers});
      console.log(response.data);

      if(response.data.status === 200){
        alert('회원가입이 되었습니다.');
        router.push({name: "TheHome"});
      }
     
    }

    return {
      state,
      email,password,repassword,mobile,name,
      // emailCheckHandler,
      joinHandler,
    }
  }
}
</script>

<style>
  label {
    display: inline-block; width: 500px; text-align: right;color: red;
  }
  /*@import url(../assets/commonstyle.css); */
</style>