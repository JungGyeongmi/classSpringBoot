package com.example.apiserverex.entity;

public enum AuthorityRole {
  USER, MEMBER, ADMIN
}
