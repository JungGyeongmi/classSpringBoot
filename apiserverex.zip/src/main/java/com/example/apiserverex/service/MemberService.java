package com.example.apiserverex.service;

import java.util.Iterator;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.example.apiserverex.dto.CommonMemberDTO;
import com.example.apiserverex.entity.AuthorityRole;
import com.example.apiserverex.entity.CommonMember;

public interface MemberService {
  void updateCommonMemberDTO(CommonMemberDTO cMemberDTO);
  Long register(CommonMemberDTO dto);

  default CommonMember dtoToEntity(CommonMemberDTO cMemberDTO) {
    cMemberDTO.setUsername(cMemberDTO.getEmail());
    System.out.println("cMemberDTO:"+cMemberDTO);
    CommonMember cMember = CommonMember.builder()
        .mno(cMemberDTO.getMno())
        .email(cMemberDTO.getEmail())
        .password(cMemberDTO.getPassword())
        .name(cMemberDTO.getName())
        .mobile(cMemberDTO.getMobile())
        .fromSocial(cMemberDTO.isFromSocial())
        // .roleSet(cMemberDTO.getAuthorities().stream().map(gran->{
        //   System.out.println("gran>>"+gran);
        //   return AuthorityRole.USER;
        // }).collect(Collectors.toSet()))
        .roleSet(cMemberDTO.getRoleSet().stream().map(
          new Function<String,AuthorityRole>() {
          @Override
          public AuthorityRole apply(String t) {
            if(t.equals("ROLE_USER")) return AuthorityRole.USER;
            else if(t.equals("ROLE_MEMBER")) return AuthorityRole.MEMBER;
            else if(t.equals("ROLE_ADMIN")) return AuthorityRole.ADMIN;
            else return AuthorityRole.USER;
          }
        }).collect(Collectors.toSet()))
        .build();
      Set<AuthorityRole> set = cMember.getRoleSet();
      if(set.size()>0){
        Iterator<AuthorityRole> it = set.iterator();
        while(it.hasNext()){
          cMember.addMemberRole(it.next());
        }
      } else {
        cMember.addMemberRole(AuthorityRole.USER);
      }
    return cMember;
  }

  default CommonMemberDTO entityToDTO(CommonMember cMember) {
    CommonMemberDTO cMemberDTO = CommonMemberDTO.builder()
        .mno(cMember.getMno())
        .email(cMember.getEmail())
        .name(cMember.getName())
        .mobile(cMember.getMobile())
        .fromSocial(cMember.isFromSocial())
        .roleSet(cMember.getRoleSet().stream().map( 
            role->new String("ROLE_"+role.name()))
            .collect(Collectors.toSet()))
        .regDate(cMember.getRegDate())
        .modDate(cMember.getModDate())
        .build();
    return cMemberDTO;
  }

}
