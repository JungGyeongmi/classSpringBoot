package com.example.apiserverex.controller;

import com.example.apiserverex.dto.CommonMemberDTO;
import com.example.apiserverex.service.MemberService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RestController
@Log4j2
@RequestMapping("/rest")
@RequiredArgsConstructor
public class MemberRestController {
  public final MemberService memberService;

  @PostMapping(value = "/memberRegister")
  public ResponseEntity<Long> register(@RequestBody CommonMemberDTO dto){
    log.info("rest/memberRegister...CommonMemberDTO:"+dto);
    Long num = memberService.register(dto);
    return new ResponseEntity<>(num, HttpStatus.OK);
  }
}
